
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USER
 */
public class DbConnection {
        private final String url="jdbc:mysql://localhost:3306/javaproject";
        private final String uName="abdu";
        private final String pass="abduadmin";

        private static Connection connection = null;
        private static DbConnection dbConn= null;
    
        public ResultSet getResults(String query) {
            ResultSet results = null;
            try {
                results = this.getStatement().executeQuery(query);
            } catch (SQLException ex) {
                Logger.getLogger(DbConnection.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            return results;
        }
        
        public int getResultsUsingPreparedStatement(String query) {
            int result = 0;
            try {
                result = this.getPreparedStatement(query).executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(DbConnection.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            return result;
        }
        
        public int executeUpdate(String query) throws SQLException {
            return this.getStatement().executeUpdate(query);
        }
        
        private Statement getStatement() {
            Statement stmnt = null;
            try {
                Class.forName("com.mysql.jdbc.Driver");
                stmnt = this.getConnection().createStatement();
            } catch (SQLException | ClassNotFoundException ex) {
                Logger.getLogger(DbConnection.class.getName()).log(Level.SEVERE, null, ex);
            }   
            return stmnt;
        }
        
        private PreparedStatement getPreparedStatement(String query) {
            PreparedStatement stmnt = null;
            try {
                Class.forName("com.mysql.jdbc.Driver");
                stmnt = this.getConnection().prepareStatement(query);
            } catch (SQLException | ClassNotFoundException ex) {
                Logger.getLogger(DbConnection.class.getName()).log(Level.SEVERE, null, ex);
            }   
            return stmnt;
        }
        
        
        private Connection getConnection() {
            if(connection == null) {
                try {
                    connection = DriverManager.getConnection(this.url,this.uName,this.pass);
                } catch (SQLException ex) {
                    Logger.getLogger(DbConnection.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
          return connection;
        }
        
        public static DbConnection getInstance() {
            if(dbConn == null) {
                dbConn = new DbConnection();
            }
            
            return dbConn;
        }
}
