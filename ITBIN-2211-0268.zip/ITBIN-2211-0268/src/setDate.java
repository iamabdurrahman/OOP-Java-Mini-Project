import java.text.SimpleDateFormat;  
import java.util.Date;  

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author SDR
 */
 
public class setDate {
    public static  Date date = new Date();
    public static String strDate="";
    
public static void getDate() {  
      
    SimpleDateFormat formatter = new SimpleDateFormat("dd MMMM yyyy");  
    strDate = formatter.format(date); 
}  
}  
